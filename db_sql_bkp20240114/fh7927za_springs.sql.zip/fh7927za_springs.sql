-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 14, 2024 at 10:14 AM
-- Server version: 5.7.21-20-beget-5.7.21-20-1-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fh7927za_springs`
--

-- --------------------------------------------------------

--
-- Table structure for table `Locations`
--
-- Creation: Dec 13, 2023 at 02:15 PM
--

DROP TABLE IF EXISTS `Locations`;
CREATE TABLE `Locations` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `tooltip` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  `author` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Locations`
--

INSERT INTO `Locations` (`id`, `name`, `longitude`, `latitude`, `tooltip`, `date`, `author`, `createdAt`, `updatedAt`) VALUES
(1, 'Живительный', '56.043374', '49.077468', 'Карась-Яр', '2023-12-13 17:23:13', 'Ushdceijwfn', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Глубокий', '53.853613', '50.218358', 'Шаман-пролив', '2023-12-13 17:23:13', 'Brisdgqwfwe', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'sdfgsdfg', '55.781536', '35.846438', 'sdfgdsfg', '2023-12-19 13:55:09', 'sdfgsdfgdsf', '2023-12-19 13:55:10', '2023-12-19 13:55:10'),
(5, 'erter', '35.846438', '55.781536', 'ewrtewrt', '2023-12-19 13:56:51', 'ewrtewrte', '2023-12-19 13:56:52', '2023-12-19 13:56:52'),
(6, 'Тюменская тайна', '57.12', '65.00', '123', '2023-12-19 14:09:55', '123', '2023-12-19 14:09:55', '2023-12-19 14:09:55'),
(7, 'укпуцкп', '65.00', '57.00', 'цйу', '2023-12-19 14:10:34', 'кцуук', '2023-12-19 14:10:35', '2023-12-19 14:10:35'),
(8, 'Рязань', '54.33', '39.33', 'куен', '2023-12-19 14:12:27', 'куенук', '2023-12-19 14:12:27', '2023-12-19 14:12:27'),
(9, 'Сургут', '73.39', '61.24', 'ывапывап', '2023-12-19 14:16:01', 'ывапывап', '2023-12-19 14:16:02', '2023-12-19 14:16:02'),
(10, 'Омск', '73.30', '55.00', 'уфывафыва', '2023-12-19 14:16:44', 'цукцукцук', '2023-12-19 14:16:44', '2023-12-19 14:16:44'),
(11, 'Шупашкар', '46.24', '56.12', 'фуыаывпыукп', '2023-12-19 17:04:39', 'ыупвыупцкупцкп', '2023-12-19 17:04:39', '2023-12-19 17:04:39'),
(12, 'Шупашкар', '46.24', '56.12', 'фуыаывпыукп', '2023-12-19 17:04:45', 'ыупвыупцкупцкп', '2023-12-19 17:04:46', '2023-12-19 17:04:46');

-- --------------------------------------------------------

--
-- Table structure for table `springs`
--
-- Creation: Dec 12, 2023 at 05:11 PM
--

DROP TABLE IF EXISTS `springs`;
CREATE TABLE `springs` (
  `name` varchar(512) NOT NULL,
  `latitude` varchar(64) NOT NULL,
  `longitude` varchar(64) NOT NULL,
  `tooltip` varchar(512) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `photo` varchar(512) NOT NULL,
  `author` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `springs`
--

INSERT INTO `springs` (`name`, `latitude`, `longitude`, `tooltip`, `added`, `photo`, `author`) VALUES
('test', '0.99999999', '0.99999999', 'Карась-Яр', '2023-12-12 17:02:13', 'ph1.jpg', 'Man'),
('Стрелецкий', '0.99999999', '0.99999999', 'Умань', '2023-12-12 17:02:13', 'ph2.jpg', 'Man'),
('test', '0.99999999', '0.99999999', 'Карась-Яр', '2023-12-12 17:02:17', 'ph1.jpg', 'Man'),
('Стрелецкий', '0.99999999', '0.99999999', 'Умань', '2023-12-12 17:02:17', 'ph2.jpg', 'Man'),
('Mad Ass', '0.99999999', '0.99999999', 'qefqwefwqefwefwef', '2023-12-12 17:07:38', 'ph.3', 'Man'),
('Mad Ass', '0.99999999', '0.99999999', 'qefqwefwqefwefwef', '2023-12-12 17:07:42', 'ph.3', 'Man');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Locations`
--
ALTER TABLE `Locations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Locations`
--
ALTER TABLE `Locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
